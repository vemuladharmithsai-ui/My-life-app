package com.mylife.tracker

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Ink = Color(0xFF10131C)
private val Panel = Color(0xFF1B2030)
private val Muted = Color(0xFF9AA4B8)
private val Accent = Color(0xFF9BAAFF)
private val Green = Color(0xFF77D6A3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        scheduleDailyReminder(this)
        setContent { MyLifeApp(this) }
    }
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel("mylife_daily", "Daily MyLife reminder", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "A gentle reminder to review your day and plan tomorrow"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.createNotificationChannel(channel)
    }
}

object MyLifeAppContext { var app: Context? = null }

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, "mylife_daily")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("A quick MyLife check-in")
                .setContentText("Record today’s progress and prepare for tomorrow.")
                .setAutoCancel(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("A quick MyLife check-in")
                .setContentText("Record today’s progress and prepare for tomorrow.")
                .setAutoCancel(true).build()
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(101, notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { scheduleDailyReminder(context) }
}

private fun scheduleDailyReminder(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, DailyReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(context, 101, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 21); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
}

private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
private fun prefs(context: Context) = context.getSharedPreferences("mylife_data", Context.MODE_PRIVATE)
private fun loadDay(context: Context, key: String): JSONObject =
    try { JSONObject(prefs(context).getString(key, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
private fun saveDay(context: Context, key: String, data: JSONObject) {
    prefs(context).edit().putString(key, data.toString()).apply()
}

@Composable
fun MyLifeApp(context: Context) {
    MyLifeAppContext.app = context.applicationContext
    var tab by remember { mutableStateOf("Today") }
    var refresh by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Today", "Track", "Plan", "History").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when(item) {
                                    "Today" -> Icons.Default.Home
                                    "Track" -> Icons.Default.EditNote
                                    "Plan" -> Icons.Default.CalendarMonth
                                    else -> Icons.Default.Insights
                                }, contentDescription = item)
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            key(refresh, tab) {
                when (tab) {
                    "Today" -> TodayScreen(context, Modifier.padding(padding), onTrack = { tab = "Track" })
                    "Track" -> TrackScreen(context, Modifier.padding(padding), onSaved = { refresh++ })
                    "Plan" -> PlanScreen(context, Modifier.padding(padding), onSaved = { refresh++ })
                    else -> HistoryScreen(context, Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
private fun ScreenColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(modifier.fillMaxSize().background(Ink).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Column(content = content) }
    }
}

@Composable
private fun TodayScreen(context: Context, modifier: Modifier, onTrack: () -> Unit) {
    val data = remember { loadDay(context, todayKey()) }
    ScreenColumn(modifier) {
        Text("MY LIFE", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Text("Today, ${SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Small steps. Better days.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Calories", data.optString("calories", "0"), "kcal", Modifier.weight(1f))
            MetricCard("Water", data.optString("water", "0"), "litres", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Study", data.optString("study", "0"), "hours", Modifier.weight(1f))
            MetricCard("Cigarettes", data.optString("cigarettes", "—"), "today", Modifier.weight(1f))
        }
        CardBlock("Today's reflection") {
            Text(data.optString("best", "Add the best thing you did today."), color = if (data.has("best")) Color.White else Muted)
        }
        CardBlock("Tomorrow's plan") {
            Text(data.optString("plan", "Plan your morning-to-night routine."), color = if (data.has("plan")) Color.White else Muted)
        }
        Button(onClick = onTrack, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Update today's record")
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(unit, color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun CardBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Accent)
            content()
        }
    }
}

@Composable
private fun Field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false, hint: String = "") {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label) },
        placeholder = { if (hint.isNotEmpty()) Text(hint) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = !label.contains("Best thing") && !label.contains("Food") && !label.contains("Tomorrow"),
        keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, focusedLabelColor = Accent,
            unfocusedBorderColor = Color(0xFF424A60), focusedTextColor = Color.White,
            unfocusedTextColor = Color.White, cursorColor = Accent
        )
    )
}

@Composable
private fun TrackScreen(context: Context, modifier: Modifier, onSaved: () -> Unit) {
    val key = todayKey()
    val data = remember { loadDay(context, key) }
    var food by remember { mutableStateOf(data.optString("food", "")) }
    var calories by remember { mutableStateOf(data.optString("calories", "")) }
    var protein by remember { mutableStateOf(data.optString("protein", "")) }
    var water by remember { mutableStateOf(data.optString("water", "")) }
    var study by remember { mutableStateOf(data.optString("study", "")) }
    var subjects by remember { mutableStateOf(data.optString("subjects", "")) }
    var cigarettes by remember { mutableStateOf(data.optString("cigarettes", "")) }
    var phone by remember { mutableStateOf(data.optString("phone", "")) }
    var privateHabit by remember { mutableStateOf(data.optString("privateHabit", "")) }
    var workout by remember { mutableStateOf(data.optString("workout", "")) }
    var sleep by remember { mutableStateOf(data.optString("sleep", "")) }
    var best by remember { mutableStateOf(data.optString("best", "")) }
    ScreenColumn(modifier) {
        Text("DAILY CHECK-IN", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Text("Track your day", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Enter what you know. You can update it later.", color = Muted)
        CardBlock("🥗 Food & nutrition") {
            Field("What did you eat? (meal + portion)", food, { food = it }, hint = "Breakfast, lunch, snacks, dinner")
            Field("Total calories (kcal)", calories, { calories = it }, true)
            Field("Protein (grams)", protein, { protein = it }, true)
            Field("Water (litres)", water, { water = it }, true)
        }
        CardBlock("📚 Studies") {
            Field("Study time (hours)", study, { study = it }, true)
            Field("Subjects / what you learned", subjects, { subjects = it }, hint = "English, maths, coding...")
        }
        CardBlock("🚭 Smoking reduction") {
            Field("Cigarettes smoked today", cigarettes, { cigarettes = it }, true)
            Text("A slip is information, not failure. Keep recording honestly.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        CardBlock("📱 Digital wellbeing") {
            Field("Phone / screen time (hours)", phone, { phone = it }, true)
        }
        CardBlock("🔒 Private habit check-in") {
            Field("Private habit notes (optional)", privateHabit, { privateHabit = it }, hint = "You can keep this brief")
        }
        CardBlock("🏋️ Fitness & recovery") {
            Field("Workout / walking / exercise", workout, { workout = it })
            Field("Sleep last night (hours)", sleep, { sleep = it }, true)
        }
        CardBlock("🏆 Best thing I did today") {
            Field("What are you proud of today?", best, { best = it }, hint = "One good thing, big or small")
        }
        Button(onClick = {
            val updated = JSONObject()
            updated.put("food", food); updated.put("calories", calories); updated.put("protein", protein)
            updated.put("water", water); updated.put("study", study); updated.put("subjects", subjects)
            updated.put("cigarettes", cigarettes); updated.put("phone", phone); updated.put("privateHabit", privateHabit)
            updated.put("workout", workout); updated.put("sleep", sleep); updated.put("best", best)
            updated.put("updatedAt", System.currentTimeMillis())
            val old = loadDay(context, key)
            val names = updated.keys()
            while (names.hasNext()) { val k = names.next(); old.put(k, updated.get(k)) }
            saveDay(context, key, old); onSaved()
        }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save today's record")
        }
    }
}

@Composable
private fun PlanScreen(context: Context, modifier: Modifier, onSaved: () -> Unit) {
    val key = todayKey()
    val data = remember { loadDay(context, key) }
    var plan by remember { mutableStateOf(data.optString("plan", "")) }
    val defaultSlots = listOf("6:00 AM — Wake up", "6:30 AM — Exercise", "8:00 AM — Breakfast", "9:00 AM — Study", "1:00 PM — Lunch", "3:00 PM — Learning / work", "6:00 PM — Gym / walk", "8:00 PM — Dinner", "9:00 PM — Review the day", "10:30 PM — Sleep")
    ScreenColumn(modifier) {
        Text("PLAN AHEAD", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Text("Make tomorrow count", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Edit this example to match your real routine.", color = Muted)
        CardBlock("Tomorrow's schedule") {
            defaultSlots.forEach { Text("•  $it", color = Color.White, modifier = Modifier.padding(vertical = 3.dp)) }
        }
        Field("Your plan for tomorrow", plan, { plan = it }, hint = "Write your own time-by-time plan")
        Button(onClick = {
            val old = loadDay(context, key); old.put("plan", plan); saveDay(context, key, old); onSaved()
        }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save tomorrow's plan")
        }
        Text("Tip: Keep your plan realistic. Leave room for travel, meals and rest.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HistoryScreen(context: Context, modifier: Modifier) {
    val all = remember {
        prefs(context).all.entries
            .filter { it.key.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }
            .sortedByDescending { it.key }
    }
    ScreenColumn(modifier) {
        Text("LOOKING BACK", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Text("Your history", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Your saved daily check-ins live on this phone.", color = Muted)
        if (all.isEmpty()) {
            CardBlock("Your first entry starts here") { Text("Save a daily check-in and it will appear here.", color = Muted) }
        } else {
            all.forEach { entry ->
                val obj = try { JSONObject(entry.value as? String ?: "{}") } catch (_: Exception) { JSONObject() }
                CardBlock(entry.key) {
                    Text("Calories: ${obj.optString("calories", "—")} kcal  •  Water: ${obj.optString("water", "—")} L", color = Muted)
                    Text("Study: ${obj.optString("study", "—")} hrs  •  Cigarettes: ${obj.optString("cigarettes", "—")}", color = Muted)
                    if (obj.optString("best").isNotBlank()) Text("Best thing: ${obj.optString("best")}")
                }
            }
        }
    }
}
