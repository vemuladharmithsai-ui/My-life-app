# MyLife Android app

A native Android starter app built with Kotlin and Jetpack Compose.

## Included
- Today dashboard
- Daily food, calories, protein and water entry
- Study time and subjects
- Cigarette count and private habit notes
- Screen time, exercise and sleep
- Best thing I did today
- Tomorrow plan
- Local daily history
- Daily 9:00 PM reminder notification (inexact Android alarm)

## Build and install
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync finish (internet is needed for the first build).
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

To make an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important notes
- This is a first working starter version, not a Play Store release.
- Data is stored locally in app SharedPreferences. Uninstalling the app or clearing its data can erase records.
- Android 13+ asks permission for notifications. Allow it to receive reminders.
- The 9 PM reminder is inexact because Android may delay background alarms to save battery.
- Food calories and nutrition are entered manually; this version does not yet have a food database or automatic calorie recognition.
- Screen time is manually entered; automatic usage access integration is not included yet.
- Private habit notes are stored locally but are not encrypted in this starter version. Avoid entering sensitive details until encryption/app lock is added.
- Review and customize the sample tomorrow schedule before relying on it.
